---
name: gemini-vision
description: Analyze images using Google Gemini 1.5 Flash (free tier). Extract text, descriptions, and insights.
version: 1.0.0
author: Silinium
license: MIT
---

# Gemini Vision Skill

Uses Google Gemini 1.5 Flash (free tier with Google AI Studio) to analyze images.

## Setup

Requires a Google AI Studio API key (free with limits).

```bash
gemini-vision config set gemini.apiKey YOUR_API_KEY
```

Or set env var: `GOOGLE_API_KEY` (or `GEMINI_API_KEY`)

## Commands

- `gemini-analyze <image_url_or_path>`: Description + OCR
- `gemini-describe <image_url_or_path>`: Only description
- `gemini-ocr <image_url_or_path>`: Only text extraction
- `gemini-ask <image_url_or_path> <question>`: Ask specific question about image

## Examples

```
gemini-analyze https://example.com/chart.png
gemini-describe ./photo.jpg
gemini-ocr ./document.png
gemini-ask ./screenshot.png "What is the Bitcoin price shown?"
```

## Notes

- Free tier: ~60 RPM, generous monthly tokens
- Images: URLs or local files (auto base64)
- Model: gemini-1.5-flash (fast, multimodal)
- Requires Node.js Google Generative AI SDK

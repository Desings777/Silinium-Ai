import { GoogleGenerativeAI } from '@google/generative-ai';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import axios from 'axios';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const args = process.argv.slice(2);

function usage() {
  console.log('Usage: vision.js <command> [args]');
  console.log('Commands:');
  console.log('  analyze <image_url_or_path>');
  console.log('  describe <image_url_or_path>');
  console.log('  ocr <image_url_or_path>');
  console.log('  ask <image_url_or_path> "<question>"');
  console.log('');
  console.log('Examples:');
  console.log('  vision.js analyze https://example.com/image.jpg');
  console.log('  vision.js describe ./photo.png');
  process.exit(1);
}

async function getApiKey() {
  const key = process.env.GOOGLE_API_KEY || process.env.GEMINI_API_KEY;
  if (key) return key;
  const configPath = path.join(process.env.HOME || '/home/ubuntu', '.openclaw', 'credentials', 'gemini-token.json');
  try {
    if (fs.existsSync(configPath)) {
      const data = JSON.parse(fs.readFileSync(configPath, 'utf8'));
      return data.apiKey || data.key || data.token;
    }
  } catch (e) {}
  return null;
}

async function readImageData(imageArg) {
  let base64Data;
  let mimeType;
  if (imageArg.startsWith('http://') || imageArg.startsWith('https://')) {
    // Download image via axios
    const res = await axios.get(imageArg, { responseType: 'arraybuffer' });
    base64Data = Buffer.from(res.data, 'binary').toString('base64');
    mimeType = res.headers['content-type'] || 'image/jpeg';
  } else {
    // Local file
    const filePath = path.resolve(imageArg);
    if (!fs.existsSync(filePath)) {
      throw new Error(`File not found: ${filePath}`);
    }
    const data = fs.readFileSync(filePath);
    base64Data = data.toString('base64');
    const ext = path.extname(filePath).toLowerCase();
    if (ext === '.png') mimeType = 'image/png';
    else if (ext === '.jpg' || ext === '.jpeg') mimeType = 'image/jpeg';
    else if (ext === '.gif') mimeType = 'image/gif';
    else if (ext === '.webp') mimeType = 'image/webp';
    else mimeType = 'image/jpeg';
  }
  return { base64Data, mimeType };
}

async function listModels(apiKey) {
  const genAI = new GoogleGenerativeAI(apiKey);
  const models = await genAI.listModels();
  return models;
}

async function callGemini(prompt, imageData, mimeType) {
  const apiKey = await getApiKey();
  if (!apiKey) {
    console.error('ERROR: Gemini API key not configured.');
    process.exit(1);
  }

  const genAI = new GoogleGenerativeAI(apiKey);

  // Try sequence of multimodal models
  const modelsToTry = ['gemini-2.5-flash', 'gemini-1.5-flash', 'gemini-1.5-pro', 'gemini-pro-vision', 'gemini-pro'];
  let lastError;

  for (const modelName of modelsToTry) {
    try {
      console.log(`Trying model: ${modelName}...`);
      const model = genAI.getGenerativeModel({ model: modelName });
      const imagePart = {
        inlineData: {
          data: imageData,
          mimeType: mimeType
        }
      };
      const result = await model.generateContent([prompt, imagePart]);
      const response = await result.response;
      console.log(`Success with ${modelName}`);
      return response.text();
    } catch (err) {
      lastError = err;
      if (!err.message.includes('not found') && !err.message.includes('unsupported')) {
        // Other error (auth, network) -> break
        break;
      }
      // else continue to next model
    }
  }

  console.error('Gemini API error:', lastError?.message || 'Unknown');
  console.error('No available multimodal model found. Your API key may not have access to Gemini vision models.');
  console.error('Make sure you have enabled the "Generative Language API" in Google Cloud Console and are using a Gemini API key from Google AI Studio.');
  process.exit(1);
}

async function main() {
  if (args.length < 2) usage();

  const [cmd, imageArg, ...rest] = args;

  let prompt;
  if (cmd === 'analyze') {
    prompt = 'Describe this image in detail and extract any visible text.';
  } else if (cmd === 'describe') {
    prompt = 'Describe this image in detail.';
  } else if (cmd === 'ocr') {
    prompt = 'Extract all text from this image, preserving spelling and layout as accurately as possible.';
  } else if (cmd === 'ask') {
    if (rest.length === 0) {
      console.error('Missing question for ask command');
      usage();
    }
    prompt = rest.join(' ');
  } else {
    usage();
  }

  try {
    const { base64Data, mimeType } = await readImageData(imageArg);
    console.log('Analyzing image with Gemini...');
    const answer = await callGemini(prompt, base64Data, mimeType);
    console.log('\n=== RESULT ===\n');
    console.log(answer);
    console.log('\n==============\n');
  } catch (err) {
    console.error('Error:', err.message);
    process.exit(1);
  }
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});

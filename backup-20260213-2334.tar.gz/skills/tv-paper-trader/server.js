#!/usr/bin/env node
import fs from 'fs';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import http from 'http';
import { fetchKlines, createOrder, getPositions, cancelOrder, normalizeSymbol } from '../bybit-connector/index.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = new URL('.', import.meta.url).pathname;

const configPath = new URL('./config.json', import.meta.url).pathname;
const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));

const ledgerPath = new URL('./ledger.json', import.meta.url).pathname;
const statePath = new URL('./state.json', import.meta.url).pathname;

function loadLedger() { return fs.existsSync(ledgerPath) ? JSON.parse(fs.readFileSync(ledgerPath, 'utf8')) : []; }
function saveLedger(ledger) { fs.writeFileSync(ledgerPath, JSON.stringify(ledger, null, 2)); }
function loadState() { return fs.existsSync(statePath) ? JSON.parse(fs.readFileSync(statePath, 'utf8')) : { balance: config.initialBalance, openTrades: [], lastUpdate: Date.now() }; }
function saveState(state) { fs.writeFileSync(statePath, JSON.stringify(state, null, 2)); }

// TA functions (same as before)
function SMA(data, period) {
  const result = []; for (let i = 0; i < data.length; i++) { if (i < period - 1) result.push(null); else { const slice = data.slice(i - period + 1, i + 1); const sum = slice.reduce((a, b) => a + b.close, 0); result.push(sum / period); } } return result;
}
function EMA(data, period) {
  const result = []; const multiplier = 2 / (period + 1); for (let i = 0; i < data.length; i++) { if (i === 0) result.push(data[0].close); else { const prevEMA = result[i-1] !== null ? result[i-1] : data[i-1].close; result.push((data[i].close - prevEMA) * multiplier + prevEMA); } } return result;
}
function RSI(data, period = 14) {
  const changes = []; for (let i = 1; i < data.length; i++) changes.push(data[i].close - data[i-1].close);
  const gains = changes.map(c => c > 0 ? c : 0); const losses = changes.map(c => c < 0 ? -c : 0);
  const avgGain = SMA(gains.map(g => ({ close: g })), period); const avgLoss = SMA(losses.map(l => ({ close: l })), period);
  const rsi = []; for (let i = 0; i < data.length; i++) { if (i < period) rsi.push(null); else { const gain = avgGain[i-1]; const loss = avgLoss[i-1]; if (!gain || !loss) rsi.push(null); else if (loss === 0) rsi.push(100); else { const rs = gain / loss; rsi.push(100 - 100 / (1 + rs)); } } } return rsi;
}
function MACD(data, fast = 12, slow = 26, signal = 9) {
  const emaFast = EMA(data, fast); const emaSlow = EMA(data, slow);
  const macdLine = []; for (let i = 0; i < data.length; i++) { if (emaFast[i] === null || emaSlow[i] === null) macdLine.push(null); else macdLine.push(emaFast[i] - emaSlow[i]); }
  const signalLine = EMA(macdLine.map((v,i) => ({ close: v })), signal);
  const histogram = macdLine.map((m,i) => (m != null && signalLine[i] != null) ? m - signalLine[i] : null);
  return { macd: macdLine, signal: signalLine, histogram };
}
function BollingerBands(data, period = 20, stdDevMult = 2) {
  const sma = SMA(data, period); const upper = []; const lower = [];
  for (let i = 0; i < data.length; i++) {
    if (sma[i] == null) { upper.push(null); lower.push(null); }
    else {
      const slice = data.slice(i - period + 1, i + 1); const mean = sma[i];
      const sqDiffs = slice.map(d => Math.pow(d.close - mean, 2));
      const variance = sqDiffs.reduce((a,b)=>a+b,0) / period; const stdDev = Math.sqrt(variance);
      upper.push(mean + stdDevMult * stdDev); lower.push(mean - stdDevMult * stdDev);
    }
  }
  return { middle: sma, upper, lower };
}
function detectSupportResistance(data, lookback = 20) {
  const recent = data.slice(-lookback);
  if (recent.length === 0) return { resistance: null, support: null };
  const highs = recent.map(d => d.high); const lows = recent.map(d => d.low);
  const maxVal = Math.max(...highs); const minVal = Math.min(...lows);
  const maxIdx = highs.indexOf(maxVal); const minIdx = lows.indexOf(minVal);
  return { resistance: recent[maxIdx]?.high || null, support: recent[minIdx]?.low || null };
}

function analyzeTA(klines) {
  const data = klines;
  if (!Array.isArray(data) || data.length === 0) throw new Error('No data for TA');
  const cleaned = data.map(d => {
    if (!d || typeof d !== 'object') return null;
    const close = Number(d.close);
    const high = Number(d.high);
    const low = Number(d.low);
    const open = Number(d.open);
    if (!isFinite(close) || !isFinite(high) || !isFinite(low) || !isFinite(open)) return null;
    return { time: Number(d.time) || 0, open, high, low, close, volume: Number(d.volume) || 0 };
  }).filter(Boolean);
  if (cleaned.length === 0) throw new Error('All klines invalid after cleaning');
  const closes = cleaned.map(d => d.close);
  const currentPrice = closes[closes.length - 1];
  const sma20 = SMA(cleaned, 20);
  const sma50 = SMA(cleaned, 50);
  const ema12 = EMA(cleaned, 12);
  const ema26 = EMA(cleaned, 26);
  const rsi = RSI(cleaned, 14);
  const { macd, signal, histogram } = MACD(cleaned);
  const bb = BollingerBands(cleaned, 20, 2);
  const { resistance, support } = detectSupportResistance(cleaned, 20);
  const idx = cleaned.length - 1;
  return {
    currentPrice,
    sma20: sma20[idx], sma50: sma50[idx],
    ema12: ema12[idx], ema26: ema26[idx],
    rsi: rsi[idx], macd: macd[idx], macdSignal: signal[idx], macdHist: histogram[idx],
    bbUpper: bb.upper[idx], bbLower: bb.lower[idx],
    resistance, support
  };
}

function isTradingAllowed() {
  if (!config.tradingHours?.enabled) return true;
  const now = new Date(); const utcHours = now.getUTCHours();
  const start = parseInt(config.tradingHours.start.split(':')[0]);
  const end = parseInt(config.tradingHours.end.split(':')[0]);
  if (start < end) return utcHours >= start && utcHours < end;
  return utcHours >= start || utcHours < end;
}

function confirmEntry(alert, ta) {
  let confidence = 0; const reasons = []; const isLong = alert.action.toLowerCase() === 'buy'; const price = ta.currentPrice;
  if (ta.sma20 && ta.sma50 && ta.ema12 && ta.ema26) {
    if (isLong) {
      if (price > ta.sma20 && price > ta.sma50) { confidence += 0.2; reasons.push('Precio > SMA20/50'); }
      if (ta.ema12 > ta.ema26) { confidence += 0.2; reasons.push('EMA12 > EMA26'); }
    } else {
      if (price < ta.sma20 && price < ta.sma50) { confidence += 0.2; reasons.push('Precio < SMA20/50'); }
      if (ta.ema12 < ta.ema26) { confidence += 0.2; reasons.push('EMA12 < EMA26'); }
    }
  }
  if (ta.rsi != null) {
    if (isLong) {
      if (ta.rsi < 30) { confidence += 0.2; reasons.push('RSI < 30'); }
      else if (ta.rsi > 70) { confidence -= 0.1; reasons.push('RSI > 70'); }
      else { confidence += 0.1; reasons.push(`RSI ${ta.rsi.toFixed(1)}`); }
    } else {
      if (ta.rsi > 70) { confidence += 0.2; reasons.push('RSI > 70 para short'); }
      else if (ta.rsi < 30) { confidence -= 0.1; reasons.push('RSI < 30'); }
      else { confidence += 0.1; reasons.push(`RSI ${ta.rsi.toFixed(1)}`); }
    }
  }
  if (ta.macd != null && ta.macdSignal != null && ta.macdHist != null) {
    if (isLong) {
      if (ta.macd > ta.macdSignal && ta.macdHist > 0) { confidence += 0.2; reasons.push('MACD alcista'); }
      else if (ta.macd < ta.macdSignal) { confidence -= 0.1; reasons.push('MACD bajista'); }
    } else {
      if (ta.macd < ta.macdSignal && ta.macdHist < 0) { confidence += 0.2; reasons.push('MACD bajista'); }
      else if (ta.macd > ta.macdSignal) { confidence -= 0.1; reasons.push('MACD alcista'); }
    }
  }
  if (ta.bbUpper && ta.bbLower) {
    if (isLong) {
      if (price < ta.bbLower) { confidence += 0.1; reasons.push('Precio cerca Bollinger inferior'); }
      else if (price > ta.bbUpper) { confidence -= 0.1; reasons.push('Precio sobre Bollinger superior'); }
    } else {
      if (price > ta.bbUpper) { confidence += 0.1; reasons.push('Precio cerca Bollinger superior'); }
      else if (price < ta.bbLower) { confidence -= 0.1; reasons.push('Precio bajo Bollinger inferior'); }
    }
  }
  if (isLong && ta.support) {
    const dist = (price - ta.support) / ta.support;
    if (Math.abs(dist) < 0.01) { confidence += 0.1; reasons.push('Precio en soporte'); }
  }
  if (!isLong && ta.resistance) {
    const dist = (ta.resistance - price) / price;
    if (Math.abs(dist) < 0.01) { confidence += 0.1; reasons.push('Precio en resistencia'); }
  }
  return { confidence: Math.max(0, Math.min(1, confidence)), reasons };
}

function calculatePositionSize(entry, sl, balance, riskPercent) {
  if (!sl) return null;
  const riskAmount = balance * (riskPercent / 100);
  const distance = Math.abs(entry - sl) / entry;
  if (distance === 0) return null;
  const sizeInUsd = riskAmount / distance;
  const sizeUnits = sizeInUsd / entry;
  return { sizeUnits, sizeUsd: riskAmount };
}

async function createRealTrade(alert, ta, sl, tp) {
  const ledger = loadLedger();
  const state = loadState();
  const entry = alert.price || ta.currentPrice;
  const side = alert.action.toLowerCase() === 'buy' ? 'long' : 'short';
  const sizing = calculatePositionSize(entry, sl, state.balance, config.riskPercent);
  if (!sizing) throw new Error('No se pudo calcular tamaño');
  const qty = sizing.sizeUnits;

  // MODO DEMO: no ejecutar orden real, solo simular
  const trade = {
    id: 'demo_' + Date.now().toString(36) + Math.random().toString(36).substr(2,5),
    symbol: normalizeSymbol(alert.ticker || alert.symbol),
    side,
    entry,
    sl,
    tp,
    size: qty,
    sizeUsd: sizing.sizeUsd,
    status: 'open',
    entryTime: new Date().toISOString(),
    exitTime: null,
    exitPrice: null,
    pnl: 0,
    notes: `strategy:${alert.strategy || 'webhook'} source:${alert.source || 'user'} mode:demo`
  };
  ledger.push(trade);
  state.openTrades.push(trade.id);
  state.lastUpdate = new Date().toISOString();
  saveLedger(ledger); saveState(state);
  console.log(`[DEMO] Trade simulado: ${trade.id} ${trade.side} ${trade.symbol} entry=${entry.toFixed(2)} sl=${sl.toFixed(2)} tp=${tp.toFixed(2)} size=${qty.toFixed(4)}`);
  return trade;
}

function closeRealTrade(trade, exitPrice, reason = 'auto') {
  const ledger = loadLedger();
  const state = loadState();
  // MODO DEMO: cerrar simulado sin llamar a Bybit
  const exitTime = new Date().toISOString();
  const pnl = trade.side === 'long'
    ? (exitPrice - trade.entry) * trade.size
    : (trade.entry - exitPrice) * trade.size;
  trade.status = 'closed';
  trade.exitTime = exitTime;
  trade.exitPrice = exitPrice;
  trade.pnl = pnl;
  state.balance += pnl;
  state.openTrades = state.openTrades.filter(id => id !== trade.id);
  state.lastUpdate = new Date().toISOString();
  saveLedger(ledger); saveState(state);
  console.log(`[DEMO] Trade cerrado: ${trade.id} ${trade.side} ${trade.symbol} exit=${exitPrice} P&L=${pnl.toFixed(2)} Balance=${state.balance.toFixed(2)}`);
  return trade;
}

async function scanOpportunities() {
  if (!isTradingAllowed()) return;
  const state = loadState();
  if (state.openTrades.length >= 3) return; // max 3 trades concurrentes
  for (const symbol of config.symbols) {
    if (state.openTrades.find(id => {
      const t = loadLedger().find(tr => tr.id === id);
      return t && t.symbol === symbol && t.status === 'open';
    })) continue;
    try {
      const klines = await fetchKlines(symbol, config.category, config.intervalForTA, 200);
      const ta = analyzeTA(klines);
      const fakeAlert = { action: 'buy', ticker: symbol, price: ta.currentPrice, strategy: 'auto-scan' };
      const confirmation = confirmEntry(fakeAlert, ta);
      if (confirmation.confidence >= config.minConfidence) {
        const pctSl = config.defaultStopLossPct / 100; const pctTp = config.defaultTakeProfitPct / 100;
        const entry = ta.currentPrice;
        const sl = entry * (1 - pctSl);
        const tp = entry * (1 + pctTp);
        const trade = await createRealTrade({ ...fakeAlert, action: 'buy' }, ta, sl, tp);
        console.log(`[${new Date().toISOString()}] AUTO-TRADE LONG ${trade.id} ${trade.symbol} entry=${entry.toFixed(2)} sl=${sl.toFixed(2)} tp=${tp.toFixed(2)} size=${trade.size} conf=${confirmation.confidence.toFixed(2)} balance=${state.balance.toFixed(2)}`);
      }
    } catch (e) {
      console.error(`Scan error ${symbol}: ${e.message}`);
      console.error(`Stack: ${e.stack}`);
    }
  }
}

async function monitorLoop() {
  const state = loadState();
  if (state.openTrades.length === 0) return;
  const openTrades = loadLedger().filter(t => t.status === 'open' && state.openTrades.includes(t.id));
  if (openTrades.length === 0) return;
  const symbols = [...new Set(openTrades.map(t => t.symbol))];
  const promises = symbols.map(async sym => {
    try {
      const klines = await fetchKlines(sym, config.category, '1m', 2);
      return { symbol: sym, price: klines[klines.length-1].close };
    } catch (e) { console.error(`Error fetching ${sym}: ${e.message}`); return { symbol: sym, price: null }; }
  });
  const results = await Promise.all(promises);
  const priceMap = {}; results.forEach(r => { if (r.price) priceMap[r.symbol] = r.price; });
  const now = new Date().toISOString();
  for (const trade of openTrades) {
    const price = priceMap[trade.symbol]; if (!price) continue;
    let exit = false, exitPrice = null;
    if (trade.side === 'long') {
      if (price <= trade.sl) { exit = true; exitPrice = trade.sl; }
      else if (price >= trade.tp) { exit = true; exitPrice = trade.tp; }
    } else {
      if (price >= trade.sl) { exit = true; exitPrice = trade.sl; }
      else if (price <= trade.tp) { exit = true; exitPrice = trade.tp; }
    }
    if (exit) {
      const closed = closeRealTrade(trade, exitPrice, 'auto');
      if (closed) {
        console.log(`[${now}] Trade ${trade.id} cerrado: ${trade.side} ${trade.symbol} exit=${exitPrice} P&L=${closed.pnl.toFixed(2)} Balance=${loadState().balance.toFixed(2)}`);
      }
    }
  }
}

function handleWebhook(req, res) {
  if (req.method !== 'POST') { res.writeHead(405); return res.end('Method Not Allowed'); }
  let body = ''; req.on('data', chunk => body += chunk); req.on('end', async () => {
    try {
      const alert = JSON.parse(body);
      if (!alert.ticker && !alert.symbol) throw new Error('Falta ticker/symbol');
      if (!alert.action) throw new Error('Falta action (buy/sell)');
      const symbol = normalizeSymbol(alert.ticker || alert.symbol);
      const isSupported = config.symbols.some(s => s.toUpperCase() === symbol);
      if (!isSupported) throw new Error(`Símbolo ${symbol} no está en la lista permitida`);
      if (config.tradingHours?.enabled && !isTradingAllowed()) {
        console.log(`[${new Date().toISOString()}] Alerta fuera de horario rechazada: ${symbol} ${alert.action}`);
        res.writeHead(200); return res.end('Rejected: outside trading hours');
      }
      const klines = await fetchKlines(symbol, config.category, config.intervalForTA, 200);
      const ta = analyzeTA(klines);

      // Alpha Scalper parameters
      let slPct = config.defaultStopLossPct / 100;
      let tpPct = config.defaultTakeProfitPct / 100;
      let minConf = config.minConfidence;
      if (alert.strategy === 'alpha-scalper') {
        slPct = 0.003;   // 0.3%
        tpPct = 0.009;   // 0.9%
        minConf = 0.4;   // más permisivo para pruebas
      }

      let sl = alert.sl; let tp = alert.tp;
      if (!sl || !tp) {
        const entry = alert.price || ta.currentPrice;
        if (alert.action.toLowerCase() === 'buy') { sl = entry * (1 - slPct); tp = entry * (1 + tpPct); }
        else { sl = entry * (1 + slPct); tp = entry * (1 - tpPct); }
      }
      const confirmation = confirmEntry({ ...alert, action: alert.action }, ta);
      if (confirmation.confidence < minConf) {
        console.log(`[${new Date().toISOString()}] Alerta rechazada: ${symbol} ${alert.action} conf=${confirmation.confidence.toFixed(2)} razones: ${confirmation.reasons.join(', ')}`);
        res.writeHead(200); return res.end('Rejected: low confidence');
      }
      sl = Number(sl.toFixed(2)); tp = Number(tp.toFixed(2));
      const trade = await createRealTrade(alert, ta, sl, tp);
      console.log(`[${new Date().toISOString()}] Trade abierto: ${trade.id} ${trade.symbol} ${trade.side} entry=${trade.entry} sl=${sl} tp=${tp} size=${trade.size} balance=${loadState().balance.toFixed(2)}`);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ status: 'opened', trade, confidence: confirmation.confidence, reasons: confirmation.reasons }));
    } catch (e) {
      console.error('Webhook error:', e.message);
      res.writeHead(400); res.end(JSON.stringify({ error: e.message }));
    }
  });
}

const server = http.createServer();
server.on('request', (req, res) => {
  if (req.url === '/webhook' && req.method === 'POST') { handleWebhook(req, res); }
  else if (req.url === '/status' && req.method === 'GET') {
    const state = loadState(); const openIds = state.openTrades; const ledger = loadLedger(); const openTrades = ledger.filter(t => openIds.includes(t.id));
    const closedTrades = ledger.filter(t => t.status === 'closed'); const totalPnl = closedTrades.reduce((sum, t) => sum + t.pnl, 0);
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ balance: state.balance, openTrades, totalTrades: ledger.length, closedTrades: closedTrades.length, totalPnl: totalPnl.toFixed(2) }));
  } else { res.writeHead(404); res.end('Not Found'); }
});

const port = config.port || 3000;
server.listen(port, '0.0.0.0', () => {
  console.log(`📡 TV Paper Trader (REAL) escuchando en puerto ${port}`);
  console.log(`Webhook endpoint: http://0.0.0.0:${port}/webhook`);
  console.log(`Initial balance (demo fallback): ${config.initialBalance} USDT`);
  console.log(`Risk per trade: ${config.riskPercent}%`);
  console.log(`Trading hours UTC: ${config.tradingHours.start}–${config.tradingHours.end} (enabled=${config.tradingHours.enabled})`);
  console.log(`Scan interval: ${config.scanIntervalSec}s`);
});

setInterval(monitorLoop, config.pollIntervalMs);
setInterval(scanOpportunities, config.scanIntervalSec * 1000);
console.log(`⌚ Monitor activado cada ${config.pollIntervalMs}ms`);
console.log(`🔎 Scanner autónomo activado cada ${config.scanIntervalSec}s`);

# TV Paper Trader Skill

Paper trading automático desde alertas de TradingView o escaneo autónomo.

## Funciones
- Servidor HTTP (puerto 3000)
- Endpoint `/webhook` recibe JSON de alertas (ticker, action, price, sl, tp)
- Valida cada alerta con análisis técnico (misma lógica que TA Analyzer)
- Calcula tamaño de posición basado en riesgo (% del balance)
- Simula órdenes con SL/TP automáticos si no vienen en la alerta
- Monitoriza precios cada 5s y cierra trades al alcanzar SL/TP
- Ledger: `ledger.json`, estado: `state.json`

## Configuración (config.json)
- `initialBalance`: 10000 USDT (demo)
- `riskPercent`: 1.0 (% por trade)
- `defaultStopLossPct`: 1.5 (% debajo/arriba entry)
- `defaultTakeProfitPct`: 3.0
- `symbols`: lista de símbolos permitidos (formato Bybit: BTCUSDT)
- `category`: "linear"
- `intervalForTA`: "5m"
- `minConfidence`: 0.6 (umbral para abrir trades)
- `pollIntervalMs`: 5000 (monitor)
- `scanIntervalSec`: 30 (escaneo autónomo)
- `tradingHours`: horario UTC opcional

## Uso
```bash
npm start
```
Luego:
- Webhook: POST http://localhost:3000/webhook
- Estado: GET http://localhost:3000/status

Ejemplo webhook:
```json
{
  "ticker": "SOLUSDT",
  "action": "buy",
  "price": 78.45,
  "strategy": "my-strategy",
  "sl": 77.0,
  "tp": 80.0
}
```

## Notes
- Demo: NO ejecuta órdenes reales
- Bybit connector: usa ../bybit-connector
- Robusto ante datos malformados
- Abre máximo 3 trades concurrentes (hardcoded)
# TA Analyzer Skill

Análisis técnico automático usando datos de Bybit (importa bybit-connector).

## Indicators
- SMA 20, 50
- EMA 12, 26
- RSI (14)
- MACD (12/26/9) con histograma
- Bandas de Bollinger (20, ±2σ)
- Soporte/Resistencia (últimos 20 periodos)
- ATR (14) – usado internamente para validación

## CLI Usage
```bash
node index.js --pair SOL/USDT --category linear --interval 1m --limit 200
```

Opciones:
--pair: Par (BTC/USDT, ETH/USDT, etc.)
--category: linear|spot|inverse
--interval: marco temporal
--limit: número de velas (máx 500)

## Output
Reporte con:
- Precio actual
- Valores de indicadores
- Lista de señales (con iconos)
- OVERALL: BULLISH | BEARISH | NEUTRAL

## Notes
- Requiere bybit-connector presente en `../bybit-connector`
- Si hay datos corruptos, se descartan automáticamente
- Sin límites de API; usa endpoint público de mercado
#!/usr/bin/env node
import { fetchKlines } from '../bybit-connector/index.js';
import { fileURLToPath } from 'url';
const __filename = fileURLToPath(import.meta.url);
const __dirname = new URL('.', import.meta.url).pathname;

function SMA(data, period) {
  const result = [];
  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) result.push(null);
    else {
      const slice = data.slice(i - period + 1, i + 1);
      const sum = slice.reduce((a, b) => a + b.close, 0);
      result.push(sum / period);
    }
  }
  return result;
}

function EMA(data, period) {
  const result = [];
  const multiplier = 2 / (period + 1);
  for (let i = 0; i < data.length; i++) {
    if (i === 0) result.push(data[0].close);
    else {
      const prevEMA = result[i-1] !== null ? result[i-1] : data[i-1].close;
      result.push((data[i].close - prevEMA) * multiplier + prevEMA);
    }
  }
  return result;
}

function RSI(data, period = 14) {
  const changes = [];
  for (let i = 1; i < data.length; i++) changes.push(data[i].close - data[i-1].close);
  const gains = changes.map(c => c > 0 ? c : 0);
  const losses = changes.map(c => c < 0 ? -c : 0);
  const avgGain = SMA(gains.map(g => ({ close: g })), period);
  const avgLoss = SMA(losses.map(l => ({ close: l })), period);
  const rsi = [];
  for (let i = 0; i < data.length; i++) {
    if (i < period) rsi.push(null);
    else {
      const gain = avgGain[i-1];
      const loss = avgLoss[i-1];
      if (!gain || !loss) rsi.push(null);
      else if (loss === 0) rsi.push(100);
      else {
        const rs = gain / loss;
        rsi.push(100 - 100 / (1 + rs));
      }
    }
  }
  return rsi;
}

function MACD(data, fast = 12, slow = 26, signal = 9) {
  const emaFast = EMA(data, fast);
  const emaSlow = EMA(data, slow);
  const macdLine = [];
  for (let i = 0; i < data.length; i++) {
    if (emaFast[i] === null || emaSlow[i] === null) macdLine.push(null);
    else macdLine.push(emaFast[i] - emaSlow[i]);
  }
  const signalLine = EMA(macdLine.map((v,i) => ({ close: v })), signal);
  const histogram = macdLine.map((m,i) => m != null && signalLine[i] != null ? m - signalLine[i] : null);
  return { macd: macdLine, signal: signalLine, histogram };
}

function BollingerBands(data, period = 20, stdDevMult = 2) {
  const sma = SMA(data, period);
  const upper = []; const lower = [];
  for (let i = 0; i < data.length; i++) {
    if (sma[i] == null) { upper.push(null); lower.push(null); }
    else {
      const slice = data.slice(i - period + 1, i + 1);
      const mean = sma[i];
      const sqDiffs = slice.map(d => Math.pow(d.close - mean, 2));
      const variance = sqDiffs.reduce((a,b)=>a+b,0) / period;
      const stdDev = Math.sqrt(variance);
      upper.push(mean + stdDevMult * stdDev);
      lower.push(mean - stdDevMult * stdDev);
    }
  }
  return { middle: sma, upper, lower };
}

function detectSupportResistance(data, lookback = 20) {
  const recent = data.slice(-lookback);
  if (recent.length === 0) return { resistance: null, support: null };
  const highs = recent.map(d => d.high);
  const lows = recent.map(d => d.low);
  const maxVal = Math.max(...highs);
  const minVal = Math.min(...lows);
  const maxIdx = highs.indexOf(maxVal);
  const minIdx = lows.indexOf(minVal);
  return { resistance: recent[maxIdx]?.high || null, support: recent[minIdx]?.low || null };
}

function analyze(data, options) {
  const closes = data.map(d => d.close);
  const currentPrice = closes[closes.length - 1];
  const sma20 = SMA(data, 20);
  const sma50 = SMA(data, 50);
  const ema12 = EMA(data, 12);
  const ema26 = EMA(data, 26);
  const rsi = RSI(data, 14);
  const { macd, signal, histogram } = MACD(data);
  const bb = BollingerBands(data, 20, 2);
  const { resistance, support } = detectSupportResistance(data, 20);
  const idx = data.length - 1;
  const report = {
    pair: options.pair, category: options.category, currentPrice,
    sma20: sma20[idx], sma50: sma50[idx],
    ema12: ema12[idx], ema26: ema26[idx],
    rsi: rsi[idx], macd: macd[idx], macdSignal: signal[idx], macdHist: histogram[idx],
    bbUpper: bb.upper[idx], bbLower: bb.lower[idx], resistance, support,
    signals: [], overall: 'NEUTRAL'
  };
  if (currentPrice > sma20[idx] && currentPrice > sma50[idx] && ema12[idx] > ema26[idx]) {
    report.signals.push('📈 Tendencia ALCISTA'); report.overall = 'BULLISH';
  } else if (currentPrice < sma20[idx] && currentPrice < sma50[idx] && ema12[idx] < ema26[idx]) {
    report.signals.push('📉 Tendencia BAJISTA'); report.overall = 'BEARISH';
  } else report.signals.push('➡️ Tendencia LATERAL/INCONCLUSA');
  if (rsi[idx] < 30) report.signals.push('⚠️ RSI < 30: SOBREVENDIDO');
  else if (rsi[idx] > 70) report.signals.push('⚠️ RSI > 70: SOBRECOMPRADO');
  else if (rsi[idx] !== null) report.signals.push(`⚖️ RSI: ${rsi[idx].toFixed(1)}`);
  if (macd[idx] != null && signal[idx] != null) {
    if (macd[idx] > signal[idx] && histogram[idx] > 0) report.signals.push('✅ MACD: cruce ALCISTA');
    else if (macd[idx] < signal[idx] && histogram[idx] < 0) report.signals.push('🔴 MACD: cruce BAJISTA');
    else report.signals.push('➡️ MACD: neutro');
  }
  if (currentPrice > bb.upper[idx]) report.signals.push('🔝 Precio sobre Bollinger Superior');
  else if (currentPrice < bb.lower[idx]) report.signals.push('🔻 Precio bajo Bollinger Inferior');
  else report.signals.push('➡️ Precio dentro de Bandas Bollinger');
  if (resistance) report.signals.push(`📊 Resistencia: ${resistance.toFixed(2)}`);
  if (support) report.signals.push(`📊 Soporte: ${support.toFixed(2)}`);
  return report;
}

function printReport(report) {
  console.log(`🔍 ANÁLISIS TÉCNICO: ${report.pair.toUpperCase()} [${report.category}]`);
  console.log(`Precio actual: ${report.currentPrice}`);
  console.log(`SMA20: ${report.sma20?.toFixed(2) ?? 'N/A'} | SMA50: ${report.sma50?.toFixed(2) ?? 'N/A'}`);
  console.log(`EMA12: ${report.ema12?.toFixed(2) ?? 'N/A'} | EMA26: ${report.ema26?.toFixed(2) ?? 'N/A'}`);
  console.log(`RSI(14): ${report.rsi?.toFixed(1) ?? 'N/A'} | MACD: ${report.macd?.toFixed(2) ?? 'N/A'} (Signal: ${report.macdSignal?.toFixed(2) ?? 'N/A'})`);
  console.log(`Bollinger: L: ${report.bbLower?.toFixed(2) ?? 'N/A'} | U: ${report.bbUpper?.toFixed(2) ?? 'N/A'}`);
  if (report.resistance) console.log(`Resistencia: ${report.resistance.toFixed(2)}`);
  if (report.support) console.log(`Soporte: ${report.support.toFixed(2)}`);
  console.log('-'.repeat(50));
  console.log('SEÑALES:');
  report.signals.forEach(s => console.log(s));
  console.log('-'.repeat(50));
  console.log(`OVERALL: ${report.overall}`);
}

function parseArgs() {
  const args = process.argv.slice(2);
  if (args.length < 2) {
    console.log('Uso: index.js --pair <PAR> --category <spot|linear|inverse> [--interval <TF>] [--limit <N>]');
    process.exit(0);
  }
  const options = {};
  for (let i = 0; i < args.length; i++) {
    if (args[i].startsWith('--')) {
      const key = args[i].slice(2);
      if (i + 1 < args.length && !args[i+1].startsWith('--')) {
        options[key] = args[i+1];
        i++;
      } else options[key] = true;
    }
  }
  return options;
}

async function main() {
  try {
    const opts = parseArgs();
    if (!opts.pair || !opts.category) throw new Error('Faltan --pair o --category');
    const interval = opts.interval || '1m';
    const limit = Math.min(Number(opts.limit) || 200, 500);
    console.log(`Obteniendo ${limit} velas ${interval} de ${opts.pair} [${opts.category}]...`);
    const klines = await fetchKlines(opts.pair, opts.category, interval, limit);
    console.log(`Datos recibidos: ${klines.length} velas`);
    const report = analyze(klines, { pair: opts.pair, category: opts.category });
    printReport(report);
  } catch (e) {
    console.error('❌ Error:', e.message);
    process.exit(1);
  }
}

main();

---
name: git-storage
description: Gestiona almacenamiento externo en GitHub. Usa para guardar/recuperar datos sin ocupar espacio local. Clone bajo demanda, commit/push automático.
---

# Git Storage Skill

Este skill gestiona almacenamiento externo usando Git/GitHub. Permite guardar y recuperar datos en un repositorio remoto sin mantener copias locales permanentes.

## Cuándo usarlo

- Necesitas guardar datos a largo plazo pero tienes poco espacio local
- Quieres historial de versiones de los datos
- Necesitas respaldos automáticos en la nube
- Quieres sincronizar datos entre múltiples lugares

## Configuración

El skill usa el repositorio configurado en `config.githubStorage.repoUrl` (ej: `https://github.com/username/repo.git`).

Para configurar:
1. Asegúrate de tener `git` instalado y configurado
2. Configura la URL del repo en `config.githubStorage.repoUrl`
3. El directorio de trabajo será `/tmp/git-storage-<timestamp>`

## Operaciones

### Guardar datos

```
guardar_archivo <ruta_relativa> <contenido>
```

Ejemplo: `guardar_archivo memory/2025-02-12.md "# Notas de hoy\n- Reunión con equipo"`

Esto:
- Clona el repo (si no está clonado ya en /tmp)
- Crea/actualiza el archivo en la ruta relativa
- Hace commit y push
- Elimina el clone temporal (opcional)

### Recuperar datos

```
leer_archivo <ruta_relativa>
```

Ejemplo: `leer_archivo MEMORY.md`

Devuelve el contenido del archivo desde GitHub.

### Listar archivos

```
listar_archivos [ruta_relativa]
```

Lista archivos en el repositorio o en una subcarpeta.

## Flujo de trabajo recomendado

1. Usar `guardar_archivo` para persistir datos importantes
2. Usar `leer_archivo` para recuperar cuando sea necesario
3. Evitar clonar el repo completo; solo operar sobre archivos específicos

## Seguridad

- El token de GitHub debe estar configurado en `gh auth login` previamente
- No almacenar tokens en el skill
- El repo debe ser accesible con los permisos adecuados

## Ejemplo de uso integrado

Cuando la memoria llegue al límite, puedo automáticamente:
- Guardar archivos antiguos en GitHub
- Mantener solo los más recientes localmente
- Recuperar archivos históricos bajo demanda

## Limitaciones

- Requiere conexión a internet para guardar/recuperar
- Depende de GitHub API (límites de rate)
- Conflictos de merge si se modifican archivos concurrentemente desde múltiples lugares

#!/usr/bin/env bash
# Git Storage CLI - gestiona almacenamiento externo en GitHub via API

set -euo pipefail

REPO="${GIT_STORAGE_REPO:-Desings777/Silinium-Ai}"

usage() {
    echo "Uso: git-storage <comando> [args]"
    echo ""
    echo "Comandos:"
    echo "  guardar <ruta> <contenido>  Guarda archivo en el repo (vía API)"
    echo "  leer <ruta>                Lee archivo del repo (vía API)"
    echo "  listar [ruta]              Lista archivos en el repo (vía API)"
    exit 1
}

guardar() {
    if [ $# -lt 2 ]; then
        echo "Uso: guardar <ruta_relativa> <contenido>" >&2
        return 1
    fi
    local ruta="$1"
    local contenido="$2"
    
    # Obtener SHA del archivo si existe
    local sha=""
    if gh api -X GET "repos/$REPO/contents/$ruta" >/dev/null 2>/dev/null; then
        sha=$(gh api -X GET "repos/$REPO/contents/$ruta" --jq '.sha' 2>/dev/null || echo "")
    fi
    
    # Codificar contenido en base64
    local content_b64
    content_b64=$(echo -n "$contenido" | base64 -w 0)
    
    # Construir JSON
    local json
    if [ -n "$sha" ]; then
        json="{\"message\":\"Update $ruta [auto]\",\"content\":\"$content_b64\",\"sha\":\"$sha\"}"
    else
        json="{\"message\":\"Create $ruta [auto]\",\"content\":\"$content_b64\"}"
    fi
    
    # Enviar a GitHub API usando --input para enviar JSON
    if echo "$json" | gh api -X PUT "repos/$REPO/contents/$ruta" --input - >/dev/null 2>&1; then
        echo "Guardado: $ruta"
    else
        echo "Error: No se pudo guardar $ruta" >&2
        return 1
    fi
}

leer() {
    if [ $# -lt 1 ]; then
        echo "Uso: leer <ruta_relativa>" >&2
        return 1
    fi
    local ruta="$1"
    
    # Descargar contenido via API
    local contenido
    contenido=$(gh api -X GET "repos/$REPO/contents/$ruta" --jq '.content' 2>/dev/null || echo "")
    
    if [ -z "$contenido" ] || [ "$contenido" = "null" ]; then
        echo "Error: Archivo '$ruta' no encontrado" >&2
        return 1
    fi
    
    # Decodificar base64
    echo "$contenido" | base64 -d
}

listar() {
    local ruta="${1:-.}"
    
    # Listar contenido via API
    gh api -X GET "repos/$REPO/contents/$ruta" --jq '.[].name' 2>/dev/null || {
        echo "Error: Ruta '$ruta' no encontrada o no accesible" >&2
        return 1
    }
}

case "${1:-}" in
    guardar)
        shift
        guardar "$@"
        ;;
    leer)
        shift
        leer "$@"
        ;;
    listar)
        shift
        listar "$@"
        ;;
    *)
        usage
        ;;
esac

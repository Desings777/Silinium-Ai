# Bybit Connector Skill

Conexión segura a Bybit API (v5) con autenticación HMAC-SHA256.

## Functions

### fetchKlines(pair, category, interval, limit)
Obtiene velas OHLC.
- `pair`: string (ej: "BTC/USDT" o "BTCUSDT")
- `category`: "linear" (futuros USDT) | "spot" | "inverse"
- `interval`: "1m","3m","5m","15m","30m","1h","2h","4h","6h","12h","1d","1w","1M"
- `limit`: número (max 1000)
Returns: Array de objetos {time, open, high, low, close, volume}

### fetchPrice(pair, category)
Obtiene ticker actual (lastPrice, bid, ask).
Returns: {symbol, lastPrice, bid1Price, ask1Price, volume24h, priceChangePercent}

### fetchOrderbook(pair, category, limit)
Orderbook (bids/asks).
Returns: {symbol, bids: [{price, size}], asks: [...]}

### fetchRecentTrades(pair, category, limit)
Trades recientes.
Returns: Array de {time, price, size, side}

### normalizeSymbol(pair)
Normaliza formato (BTC/USDT -> BTCUSDT, USD -> USDT).

## CLI Usage
```bash
node index.js --price BTC/USDT --category linear
node index.js --klines SOL/USDT --category linear --interval 1m --limit 200
```

## Security
- API key y secret almacenados en `config/credentials.json` (chmod 600)
- Se firman las solicitudes con HMAC-SHA256
- Puerto: no abre puertos, es librería

## Notes
- Bybit v5: sensible a mayúsculas en símbolos (usa normalized)
- No expone XAU/USD (TradFi) por API pública
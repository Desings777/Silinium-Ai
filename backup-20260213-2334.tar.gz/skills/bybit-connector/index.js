#!/usr/bin/env node
import fs from 'fs';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
const __filename = fileURLToPath(import.meta.url);
const __dirname = new URL('.', import.meta.url).pathname;

const CRED_PATH = new URL('./config/credentials.json', import.meta.url).pathname;
const BYBIT_API_URL_V5 = 'https://api.bybit.com';
const RECV_WINDOW = '5000';

function loadCredentials() {
  const cred = JSON.parse(fs.readFileSync(CRED_PATH, 'utf8'));
  return { apiKey: cred.apiKey, apiSecret: cred.apiSecret };
}

function makeHeaders(apiKey, signature, timestamp) {
  return {
    'X-BAPI-API-KEY': apiKey,
    'X-BAPI-SIGN': signature,
    'X-BAPI-TIMESTAMP': timestamp,
    'Content-Type': 'application/json'
  };
}

function normalizeSymbol(pair) {
  if (pair.includes('/')) {
    const [base, quote] = pair.split('/');
    const normQuote = quote.toUpperCase() === 'USD' ? 'USDT' : quote.toUpperCase();
    return base.toUpperCase() + normQuote;
  }
  return pair.toUpperCase();
}

async function fetchKlines(pair, category = 'linear', interval = '1', limit = 200) {
  const { apiKey, apiSecret } = loadCredentials();
  const symbol = normalizeSymbol(pair);
  const intervalMap = { '1m':'1','3m':'3','5m':'5','15m':'15','30m':'30','1h':'60','2h':'120','4h':'240','6h':'360','12h':'720','1d':'D','1w':'W','1M':'M' };
  const bybitInterval = intervalMap[interval] || interval;
  const endpoint = '/v5/market/kline';
  const url = new URL(endpoint, BYBIT_API_URL_V5);
  url.searchParams.append('category', category);
  url.searchParams.append('symbol', symbol);
  url.searchParams.append('interval', bybitInterval);
  url.searchParams.append('limit', limit);
  const timestamp = Date.now().toString();
  // Public: sign over path only (no query) - this has been working
  const signature = crypto.createHmac('sha256', apiSecret).update(timestamp + 'GET' + url.pathname + '').digest('hex');
  const headers = makeHeaders(apiKey, signature, timestamp);
  const res = await fetch(url, { method: 'GET', headers });
  const text = await res.text();
  let data;
  try { data = JSON.parse(text); } catch (e) { throw new Error('Invalid JSON from Bybit'); }
  if (data.retCode != '0') throw new Error(`Bybit API ${data.retCode}: ${data.retMsg}`);
  if (!data.result || !Array.isArray(data.result.list) || data.result.list.length === 0) throw new Error('Empty klines list');
  const rawList = data.result.list;
  const parsed = rawList.map(k => {
    if (Array.isArray(k)) {
      return { time: Number(k[0]) || 0, open: Number(k[1]) || 0, high: Number(k[2]) || 0, low: Number(k[3]) || 0, close: Number(k[4]) || 0, volume: Number(k[5]) || 0 };
    } else if (k && typeof k === 'object') {
      return { time: Number(k.start ?? k.Start ?? k.startTime ?? 0), open: Number(k.open ?? k.Open ?? 0), high: Number(k.high ?? k.High ?? 0), low: Number(k.low ?? k.Low ?? 0), close: Number(k.close ?? k.Close ?? 0), volume: Number(k.volume ?? k.Volume ?? 0) };
    } else { return null; }
  }).filter(Boolean);
  if (parsed.length === 0) throw new Error('All klines data invalid after parsing');
  return parsed;
}

async function fetchPrice(pair, category = 'linear') {
  const { apiKey, apiSecret } = loadCredentials();
  const symbol = normalizeSymbol(pair);
  const endpoint = '/v5/market/tickers';
  const url = new URL(endpoint, BYBIT_API_URL_V5);
  url.searchParams.append('category', category);
  url.searchParams.append('symbol', symbol);
  const timestamp = Date.now().toString();
  const signature = crypto.createHmac('sha256', apiSecret).update(timestamp + 'GET' + url.pathname + '').digest('hex');
  const headers = makeHeaders(apiKey, signature, timestamp);
  const res = await fetch(url, { method: 'GET', headers });
  const text = await res.text();
  let data; try { data = JSON.parse(text); } catch (e) { throw new Error('Invalid JSON from Bybit'); }
  if (data.retCode != '0') throw new Error(`Bybit API ${data.retCode}: ${data.retMsg}`);
  if (!data.result) throw new Error('No price data');
  const ticker = data.result.list[0];
  return { symbol: ticker.symbol, lastPrice: Number(ticker.lastPrice), bid1Price: Number(ticker.bid1Price), ask1Price: Number(ticker.ask1Price), volume24h: Number(ticker.volume24h), priceChangePercent: Number(ticker.price24hPcnt) };
}

async function fetchBalance(accountType = 'CONTRACT') {
  const { apiKey, apiSecret } = loadCredentials();
  const endpoint = '/v5/account/wallet-balance';
  const url = new URL(endpoint, BYBIT_API_URL_V5);
  url.searchParams.append('accountType', accountType);
  // No recv_window in query; will be in header
  const timestamp = Date.now().toString();
  const signature = crypto.createHmac('sha256', apiSecret).update(timestamp + 'GET' + url.pathname + '').digest('hex');
  const headers = {
    'X-BAPI-API-KEY': apiKey,
    'X-BAPI-SIGN': signature,
    'X-BAPI-TIMESTAMP': timestamp,
    'X-BAPI-RECV-WINDOW': RECV_WINDOW,
    'Content-Type': 'application/json'
  };
  const res = await fetch(url, { method: 'GET', headers });
  const text = await res.text();
  let data; try { data = JSON.parse(text); } catch (e) { throw new Error('Invalid JSON from Bybit (balance)'); }
  if (data.retCode != '0') throw new Error(`Bybit API ${data.retCode}: ${data.retMsg}`);
  return data.result;
}

async function createOrder(params) {
  const { apiKey, apiSecret } = loadCredentials();
  const endpoint = '/v5/order/create';
  const url = new URL(endpoint, BYBIT_API_URL_V5);
  // Do NOT add recv_window to query; will be in header
  const timestamp = Date.now().toString();
  const body = JSON.stringify(params);
  const signature = crypto.createHmac('sha256', apiSecret).update(timestamp + 'POST' + url.pathname + body).digest('hex');
  const headers = {
    'X-BAPI-API-KEY': apiKey,
    'X-BAPI-SIGN': signature,
    'X-BAPI-TIMESTAMP': timestamp,
    'X-BAPI-RECV-WINDOW': RECV_WINDOW,
    'Content-Type': 'application/json'
  };
  const res = await fetch(url, { method: 'POST', headers, body });
  const text = await res.text();
  let data; try { data = JSON.parse(text); } catch (e) { throw new Error('Invalid JSON from Bybit (createOrder)'); }
  if (data.retCode != '0') throw new Error(`Bybit API ${data.retCode}: ${data.retMsg}`);
  return data.result;
}

async function getPositions(category = 'linear') {
  const { apiKey, apiSecret } = loadCredentials();
  const endpoint = '/v5/position/list';
  const url = new URL(endpoint, BYBIT_API_URL_V5);
  url.searchParams.append('category', category);
  const timestamp = Date.now().toString();
  const signature = crypto.createHmac('sha256', apiSecret).update(timestamp + 'GET' + url.pathname + '').digest('hex');
  const headers = {
    'X-BAPI-API-KEY': apiKey,
    'X-BAPI-SIGN': signature,
    'X-BAPI-TIMESTAMP': timestamp,
    'X-BAPI-RECV-WINDOW': RECV_WINDOW,
    'Content-Type': 'application/json'
  };
  const res = await fetch(url, { method: 'GET', headers });
  const text = await res.text();
  let data; try { data = JSON.parse(text); } catch (e) { throw new Error('Invalid JSON from Bybit (positions)'); }
  if (data.retCode != '0') throw new Error(`Bybit API ${data.retCode}: ${data.retMsg}`);
  return data.result;
}

async function cancelOrder(params) {
  const { apiKey, apiSecret } = loadCredentials();
  const endpoint = '/v5/order/cancel';
  const url = new URL(endpoint, BYBIT_API_URL_V5);
  const timestamp = Date.now().toString();
  const body = JSON.stringify(params);
  const signature = crypto.createHmac('sha256', apiSecret).update(timestamp + 'POST' + url.pathname + body).digest('hex');
  const headers = {
    'X-BAPI-API-KEY': apiKey,
    'X-BAPI-SIGN': signature,
    'X-BAPI-TIMESTAMP': timestamp,
    'X-BAPI-RECV-WINDOW': RECV_WINDOW,
    'Content-Type': 'application/json'
  };
  const res = await fetch(url, { method: 'POST', headers, body });
  const text = await res.text();
  let data; try { data = JSON.parse(text); } catch (e) { throw new Error('Invalid JSON from Bybit (cancelOrder)'); }
  if (data.retCode != '0') throw new Error(`Bybit API ${data.retCode}: ${data.retMsg}`);
  return data.result;
}

export { fetchKlines, fetchPrice, fetchBalance, createOrder, getPositions, cancelOrder, normalizeSymbol };

if (import.meta.url === `file://${process.argv[1]}`) {
  const args = process.argv.slice(2);
  if (args.includes('--price')) {
    const pair = args[args.indexOf('--price')+1];
    const category = args[args.indexOf('--category')+1] || 'linear';
    fetchPrice(pair, category).then(console.log).catch(console.error);
  } else if (args.includes('--klines')) {
    const pair = args[args.indexOf('--klines')+1];
    const category = args[args.indexOf('--category')+1] || 'linear';
    const interval = args[args.indexOf('--interval')+1] || '1m';
    const limit = parseInt(args[args.indexOf('--limit')+1]) || 200;
    fetchKlines(pair, category, interval, limit).then(console.log).catch(console.error);
  } else if (args.includes('--balance')) {
    const accountType = args[args.indexOf('--balance')+1] || 'CONTRACT';
    fetchBalance(accountType).then(console.log).catch(console.error);
  } else {
    console.log('Usage: index.js --price <pair> [--category <linear|spot|inverse>]');
    console.log('       index.js --klines <pair> [--category] [--interval] [--limit]');
    console.log('       index.js --balance [--accountType CONTRACT|SPOT|UNIFIED]');
  }
}

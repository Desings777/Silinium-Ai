#!/usr/bin/env bash
# Remote Assets Manager - descarga y gestiona assets remotos

set -uo pipefail

REPO="${REMOTE_ASSETS_REPO:-Desings777/Silinium-Ai}"
CACHE_DIR="${REMOTE_ASSETS_CACHE:-/tmp/remote-assets-cache}"
MANIFEST_URL="https://raw.githubusercontent.com/${REPO}/main/assets-manifest.json"

usage() {
    echo "Uso: remote-assets <comando> [args]"
    echo ""
    echo "Comandos:"
    echo "  download <skill> <asset-id> [destino]  Descarga un asset"
    echo "  list [skill]                           Lista assets disponibles"
    echo "  verify <ruta> <sha256>                Verifica checksum"
    exit 1
}

ensure_cache() {
    mkdir -p "$CACHE_DIR"
}

download() {
    if [ $# -lt 2 ]; then
        echo "Uso: download <skill> <asset-id> [destino]" >&2
        return 1
    fi
    local skill="$1"
    local asset_id="$2"
    local destino="${3:-}"
    
    ensure_cache
    
    # Descargar manifest
    local manifest_file="$CACHE_DIR/manifest.json"
    if ! curl -s -f -o "$manifest_file" "$MANIFEST_URL" 2>/dev/null; then
        echo "Error: No se pudo descargar manifest desde $MANIFEST_URL" >&2
        return 1
    fi
    
    # Buscar asset en manifest
    asset_line=$(grep -m1 -n "\"id\":\"$asset_id\"" "$manifest_file" || true)
    if [ -z "$asset_line" ]; then
        echo "Error: Asset '$asset_id' no encontrado en manifest" >&2
        return 1
    fi
    
    # Extraer campos usando contexto
    local start_line
    start_line=$(echo "$asset_line" | cut -d: -f1)
    local asset_block
    asset_block=$(sed -n "${start_line},$((start_line+6))p" "$manifest_file")
    
    local url name sha256 size
    url=$(echo "$asset_block" | grep '"url"' | head -1 | sed 's/.*"url":"\([^"]*\)".*/\1/')
    sha256=$(echo "$asset_block" | grep '"sha256"' | head -1 | sed 's/.*"sha256":"\([^"]*\)".*/\1/')
    name=$(echo "$asset_block" | grep '"name"' | head -1 | sed 's/.*"name":"\([^"]*\)".*/\1/')
    size=$(echo "$asset_block" | grep '"size"' | head -1 | sed 's/.*"size":\([0-9]*\).*/\1/')
    
    if [ -z "$url" ] || [ -z "$sha256" ] || [ -z "$name" ]; then
        echo "Error: Asset mal formado en manifest" >&2
        return 1
    fi
    
    # Determinar destino
    if [ -z "$destino" ]; then
        destino="$CACHE_DIR/${skill}-$asset_id-$name"
    fi
    
    # Si ya existe y coincide SHA, skip
    if [ -f "$destino" ]; then
        local current_sha
        current_sha=$(sha256sum "$destino" 2>/dev/null | awk '{print $1}' || echo "")
        if [ "$current_sha" = "$sha256" ]; then
            echo "Cache hit: $destino"
            echo "$destino"
            return 0
        fi
    fi
    
    # Descargar asset
    echo "Descargando $asset_id ($size bytes)..."
    if ! curl -s -L -o "$destino" "$url"; then
        echo "Error: Falló la descarga" >&2
        return 1
    fi
    
    # Verificar checksum
    local downloaded_sha
    downloaded_sha=$(sha256sum "$destino" | awk '{print $1}')
    if [ "$downloaded_sha" != "$sha256" ]; then
        echo "Error: Checksum mismatch (esperado $sha256, recibido $downloaded_sha)" >&2
        rm -f "$destino"
        return 1
    fi
    
    chmod +x "$destino" 2>/dev/null || true
    
    echo "Descargado: $destino"
    echo "$destino"
}

list_assets() {
    local skill_filter="${1:-}"
    
    ensure_cache
    
    local manifest_file="$CACHE_DIR/manifest.json"
    if [ ! -f "$manifest_file" ]; then
        if ! curl -s -f -o "$manifest_file" "$MANIFEST_URL" 2>/dev/null; then
            echo "Error: No se pudo obtener manifest" >&2
            return 1
        fi
    fi
    
    if [ ! -s "$manifest_file" ]; then
        echo "No hay assets registrados (manifest vacío)"
        return 0
    fi
    
    # Desactivar exit on error para pipes
    set +e
    
    if [ -z "$skill_filter" ]; then
        # Lista todos los assets
        grep -o '"id":[^,]*' "$manifest_file" 2>/dev/null | cut -d'"' -f4 | while read id; do
            name=$(grep -A5 "\"id\":\"$id\"" "$manifest_file" | grep '"name"' | head -1 | cut -d'"' -f4)
            skill=$(grep -A5 "\"id\":\"$id\"" "$manifest_file" | grep '"skill"' | head -1 | cut -d'"' -f4)
            size=$(grep -A5 "\"id\":\"$id\"" "$manifest_file" | grep '"size"' | head -1 | cut -d':' -f2 | tr -d ' ')
            size_mb=$(echo "$size / 1024 / 1024" | bc -l 2>/dev/null || echo "0")
            printf "%s (%s) - %s (%.2f MB)\n" "$id" "$skill" "$name" "$size_mb"
        done
    else
        # Filtra por skill
        grep -A5 "\"skill\":\"$skill_filter\"" "$manifest_file" 2>/dev/null | grep -o '"id":[^,]*' | cut -d'"' -f4 | while read id; do
            name=$(grep -A5 "\"id\":\"$id\"" "$manifest_file" | grep '"name"' | head -1 | cut -d'"' -f4)
            size=$(grep -A5 "\"id\":\"$id\"" "$manifest_file" | grep '"size"' | head -1 | cut -d':' -f2 | tr -d ' ')
            size_mb=$(echo "$size / 1024 / 1024" | bc -l 2>/dev/null || echo "0")
            printf "%s - %s (%.2f MB)\n" "$id" "$name" "$size_mb"
        done
    fi
    
    set -e
}

verify() {
    if [ $# -lt 2 ]; then
        echo "Uso: verify <ruta> <sha256>" >&2
        return 1
    fi
    local ruta="$1"
    local expected="$2"
    
    if [ ! -f "$ruta" ]; then
        echo "Error: Archivo no encontrado: $ruta" >&2
        return 1
    fi
    
    local actual
    actual=$(sha256sum "$ruta" | awk '{print $1}')
    
    if [ "$actual" = "$expected" ]; then
        echo "✓ Verificación OK: $ruta"
        return 0
    else
        echo "✗ Verificación fallida: $ruta"
        echo "  Esperado: $expected"
        echo "  Recibido: $actual"
        return 1
    fi
}

case "${1:-}" in
    download)
        shift
        download "$@"
        ;;
    list)
        shift
        list_assets "$@"
        ;;
    verify)
        shift
        verify "$@"
        ;;
    *)
        usage
        ;;
esac

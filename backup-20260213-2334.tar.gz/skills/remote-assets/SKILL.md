---
name: remote-assets
description: Gestiona assets/binarios pesados almacenados en GitHub Releases. Descarga bajo demanda, cache y verificación de integridad.
---

# Remote Assets Skill

Este skill permite guardar y descargar archivos binarios pesados desde GitHub Releases, evitando ocupar espacio local innecesario.

## Cuándo usarlo

- Skills que requieren binarios grandes (modelos ML, CLIs pesadas)
- Quieres ahorrar espacio en disco local
- Necesitas acceso a assets bajo demanda
- Quieres mantener versiones específicas de herramientas

## Configuración

El skill usa:
- `REMOTE_ASSETS_REPO`: Repositorio con releases (ej: `Desings777/Silinium-Ai-assets`)
- `REMOTE_ASSETS_CACHE`: Directorio de cache (por defecto `/tmp/remote-assets-cache`)

Configurar en `env.vars` de OpenClaw.

## Uso

### Descargar un asset

```
download <skill> <asset-id> [destino]
```

Ejemplo: `download whisper whisper-cli-linux-x64 /usr/local/bin/whisper`

- `skill`: nombre de la skill que requiere el asset
- `asset-id`: identificador único del asset (ej: `whisper-cli-linux-x64`)
- `destino`: ruta opcional donde guardar (por defecto: cache dir)

### Listar assets disponibles

```
list [skill]
```

Muestra todos los assets registrados o los de una skill específica.

### Verificar integridad

```
verify <ruta> <sha256>
```

Compara el SHA256 de un archivo descargado.

## Manifest

El skill requiere un archivo `assets-manifest.json` en el repo que defina:

```json
{
  "assets": [
    {
      "id": "whisper-cli-linux-x64",
      "skill": "openai-whisper",
      "name": "whisper-cli",
      "description": "OpenAI Whisper CLI binary",
      "release": "v20231215",
      "tag": "whisper-cli-v20231215",
      "url": "https://github.com/Desings777/Silinium-Ai-assets/releases/download/whisper-cli-v20231215/whisper",
      "sha256": "abc123...",
      "size": 157286400,
      "platform": "linux-x64"
    }
  ]
}
```

## Flujo recomendado

1. Subir binarios grandes a GitHub Releases del repo de assets
2. Actualizar `assets-manifest.json` con los metadatos y checksums
3. En la skill, usar `remote-assets download` para obtener el binario
4. Cachear en `/tmp` (se elimina automáticamente después de uso si es necesario)
5. Ejecutar el binario desde la ruta devuelta

## Beneficios

- ✅ No ocupa espacio en el workspace permanente
- ✅ Descarga bajo demanda
- ✅ Cache automático por sesión
- ✅ Verificación de integridad SHA256
- ✅ Versionado claro via tags de releases

## Ejemplo integrado

En la skill `openai-whisper`:

```
Necesitas el binario whisper. Voy a descargarlo:
```

Llamo a `remote-assets download openai-whisper whisper-cli-linux-x64 /tmp/whisper`
Y ejecuto `/tmp/whisper audio.mp3`

## Limitaciones

- Requiere acceso a GitHub (autenticado con `gh`)
- Los assets deben estar en GitHub Releases (no en el árbol del repo)
- Necesita internet para primera descarga
- Cache por sesión, no persistente entre reinicios (opcional configurar)

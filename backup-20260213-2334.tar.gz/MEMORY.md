# MEMORY.md - Long-term memories

# MEMORY.md - Recuerdos duraderos

## Identidad
- **Nombre:** Silinium (🌀)
- **Idioma:** Español
- **Usuario:** Fabian
- **Vibe:** Calm, directo, competente, respetuoso con privacidad

## Configuración actual (2026-02-13)
- **Canales activos:** WhatsApp (+56927889304), Telegram (6929141931), Discord
- **OpenClaw:** v2026.2.12
- **Skills clave:**
  - git-storage: guarda datos en GitHub repo `Desings777/Silinium-Ai`
  - remote-assets: descarga binarios grandes de Releases
  - answeroverflow: búsqueda en Discord indexado
- **Almacenamiento:** ~2.2 GB libres en VPS
- **Política:** Evitar carga innecesaria de contexto; preservar daily memory para continuidad

## Pendientes importantes
1. **Firewall:** Instalar ufw urgente
2. **Control de luces:** Configurar Tuya API (developer.tuya.com)
3. **Whisper:** Subir binario a GitHub Releases y configurar skill
4. **WhatsApp:** considerar migrar de wacli a Business API oficial

## Observaciones
- wacli funciona pero no es oficial; inestable (desconexiones)
- Memory-search aún no activado (daily files cargados cada sesión)
- Breaking change en hooks: `sessionKey` overrides bloqueados por defecto (no afecta actual)

## Decisiones tomadas
- Externalizar storage a GitHub (git-storage) para ahorrar espacio local
- Descargar binarios pesados on-demand (remote-assets) con cache en /tmp
- Mantener daily files a pesar de costo de tokens (continuidad conversación)
- Actualizar OpenClaw a 2026.2.12 por seguridad
- Discord via plugin oficial (funcionando con cron de clima)

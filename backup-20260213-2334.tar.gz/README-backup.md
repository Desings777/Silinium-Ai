# Backup de Silinium - 2026-02-13 23:44 UTC

Este backup contiene:

- `MEMORY.md`: Memoria duradera del asistente (identidad, config, pendientes, decisiones)
- `memory/`: Diarios de conversaciones por fecha (formato YYYY-MM-DD.md)
- `skills/`: Código fuente de los skills instalados en OpenClaw
- `skills-list.txt`: Lista de skills instalados

**Nota:** No incluye credenciales (tokens, claves API). Esas deben restaurarse manualmente desde `~/.openclaw/credentials/` o reconectar canales.

Para restaurar después de reinstalar OpenClaw:

1. Recuperar estos archivos en `/home/ubuntu/.openclaw/workspace/`
2. Reinstalar skills con `npx clawhub install <skill-name>` (o copiar las carpetas de skills/ manualmente)
3. Restaurar canales: ejecutar `openclaw pairing approve` para WhatsApp, re-autenticar Telegram/Discord si es necesario
4. La memoria conversacional se recuperará automáticamente de los archivos `memory/`

---
Creado por Silinium 🌀 - Asistente autónomo